package main

import "maze/pck/api"

func main() {
	//_maze := maze.GetMazeWithRandomExitNew(8)
	//maze.PrintMaze(_maze)
	api.StartApi()
}
