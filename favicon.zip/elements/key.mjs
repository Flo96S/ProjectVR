export function createKey() {
   function checkIfOverlapp(player) {

   }
}