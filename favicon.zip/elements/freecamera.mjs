document.addEventListener("keydown", (ev) => down());
document.addEventListener("keyup", (ev) => up());


function down() {
   console.log("Hello DOWN")
}

function up() {

}