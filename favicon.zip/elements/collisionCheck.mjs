export function checkCollision(player, walls) {

}