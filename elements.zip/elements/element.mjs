import * as THREE from 'three';

export function Beton() {
   const loader = new THREE.FBXLoader()
}